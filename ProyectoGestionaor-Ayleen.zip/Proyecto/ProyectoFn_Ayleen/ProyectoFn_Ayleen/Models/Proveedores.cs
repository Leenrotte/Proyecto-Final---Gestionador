﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventarioApp.Models
{
    // Clase que representa un proveedor en el sistema de inventario.
    public class Proveedor
    {
        // Identificador único del proveedor.
        public int Id { get; set; }

        // Nombre de la empresa del proveedor.
        public string NombreEmpresa { get; set; }

        // Información de contacto del proveedor (nombre de la persona de contacto o responsable).
        public string Contacto { get; set; }

        // Dirección física del proveedor.
        public string Direccion { get; set; }

        // Número de teléfono del proveedor.
        public string Telefono { get; set; }
    }
}
