﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using InventarioApp.Models;

namespace InventarioApp.Controllers
{
    public class ProductoController
    {
        // Cadena de conexión a la base de datos. Cambiar según los detalles del entorno.
        private string connectionString = "Data Source=localhost\\SQLEXPRESS;Initial Catalog=InventarioDB;Integrated Security=True";

        // Método para obtener una lista de productos desde la base de datos
        public List<Producto> ObtenerProductos()
        {
            List<Producto> productos = new List<Producto>();

            // Se abre una conexión con la base de datos usando la cadena de conexión.
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open(); // Abre la conexión.

                // Comando SQL para seleccionar todos los registros de la tabla Productos.
                SqlCommand cmd = new SqlCommand("SELECT * FROM Productos", con);

                // Ejecuta el comando y obtiene los resultados en un SqlDataReader.
                SqlDataReader reader = cmd.ExecuteReader();

                // Lee cada fila devuelta por la consulta.
                while (reader.Read())
                {
                    // Agrega cada producto a la lista usando los datos del lector.
                    productos.Add(new Producto
                    {
                        Id = (int)reader["Id"], // Asigna el valor del campo "Id".
                        Nombre = reader["Nombre"].ToString(), // Convierte el campo "Nombre" a string.
                        Codigo = reader["Codigo"].ToString(), // Convierte el campo "Codigo" a string.
                        CategoriaId = (int)reader["CategoriaId"], // Asigna el valor del campo "CategoriaId".
                        Precio = (decimal)reader["Precio"], // Asigna el valor del campo "Precio".
                        Existencia = (int)reader["Existencia"], // Asigna el valor del campo "Existencia".
                        ProveedorId = (int)reader["ProveedorId"] // Asigna el valor del campo "ProveedorId".
                    });
                }
            }

            // Retorna la lista completa de productos obtenidos de la base de datos.
            return productos;
        }

        // Método para agregar un nuevo producto a la base de datos.
        public void AgregarProducto(Producto producto)
        {
            // Se abre una conexión con la base de datos.
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open(); // Abre la conexión.

                // Comando SQL para insertar un nuevo producto en la tabla Productos.
                SqlCommand cmd = new SqlCommand("INSERT INTO Productos (Nombre, Codigo, CategoriaId, Precio, Existencia, ProveedorId) VALUES (@Nombre, @Codigo, @CategoriaId, @Precio, @Existencia, @ProveedorId)", con);

                // Se añaden los parámetros al comando para evitar inyecciones SQL.
                cmd.Parameters.AddWithValue("@Nombre", producto.Nombre); // Parámetro para el nombre del producto.
                cmd.Parameters.AddWithValue("@Codigo", producto.Codigo); // Parámetro para el código del producto.
                cmd.Parameters.AddWithValue("@CategoriaId", producto.CategoriaId); // Parámetro para la categoría.
                cmd.Parameters.AddWithValue("@Precio", producto.Precio); // Parámetro para el precio.
                cmd.Parameters.AddWithValue("@Existencia", producto.Existencia); // Parámetro para la existencia.
                cmd.Parameters.AddWithValue("@ProveedorId", producto.ProveedorId); // Parámetro para el proveedor.

                // Ejecuta el comando para insertar el nuevo producto en la base de datos.
                cmd.ExecuteNonQuery();
            }
        }


    }
}
