﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using InventarioApp.Controllers;
using InventarioApp.Models;
using ProyectoFn_Ayleen.Controllers; // Asegúrate de que el controlador de productos esté en este espacio de nombres
using ProyectoFn_Ayleen.Models; // Modelo de Producto y otros relacionados

namespace ProyectoFn_Ayleen.Views
{
    public partial class FormProductos : Form
    {
        private ProductoController productoController; // Controlador para manejar las operaciones de productos
        private List<Categoria> categorias; // Lista para las categorías
        private List<Proveedor> proveedores; // Lista para los proveedores

        public FormProductos()
        {
            InitializeComponent();
            productoController = new ProductoController();
            CargarCategorias(); // Cargar las categorías al inicio
            CargarProveedores(); // Cargar los proveedores al inicio
            CargarProductos(); // Cargar los productos al inicio
        }

        // Cargar categorías en el comboBox
        private void CargarCategorias()
        {
            categorias = productoController.ObtenerCategorias();
            cmbCategoria.DataSource = categorias;
            cmbCategoria.DisplayMember = "Nombre";
            cmbCategoria.ValueMember = "Id";
        }

        // Cargar proveedores en el comboBox
        private void CargarProveedores()
        {
            proveedores = productoController.ObtenerProveedores();
            cmbProveedor.DataSource = proveedores;
            cmbProveedor.DisplayMember = "NombreEmpresa";
            cmbProveedor.ValueMember = "Id";
        }

        // Cargar productos en una lista o tabla
        private void CargarProductos()
        {
            dgvProductos.DataSource = productoController.ObtenerProductos();
        }

        // Evento cuando se cambia la categoría seleccionada
        private void cmbCategoria_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Obtener la categoría seleccionada y realizar alguna acción si es necesario
            var categoriaSeleccionada = (Categoria)cmbCategoria.SelectedItem;
        }

        // Evento cuando se cambia el proveedor seleccionado
        private void cmbProveedor_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Obtener el proveedor seleccionado y realizar alguna acción si es necesario
            var proveedorSeleccionado = (Proveedor)cmbProveedor.SelectedItem;
        }

        // Evento cuando se hace clic en el botón de agregar producto
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            Producto nuevoProducto = new Producto
            {
                Nombre = txtNombre.Text,
                Codigo = txtCodigo.Text,
                CategoriaId = (int)cmbCategoria.SelectedValue,
                ProveedorId = (int)cmbProveedor.SelectedValue,
                Precio = decimal.Parse(txtPrecio.Text),
                Existencia = int.Parse(txtExistencia.Text)
            };

            productoController.AgregarProducto(nuevoProducto);
            MessageBox.Show("Producto agregado exitosamente.");
            CargarProductos(); // Refrescar la lista de productos
        }

        // Evento cuando se hace clic en el botón de editar producto
        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (dgvProductos.SelectedRows.Count > 0)
            {
                // Obtener el producto seleccionado de la tabla
                Producto productoSeleccionado = (Producto)dgvProductos.SelectedRows[0].DataBoundItem;

                // Actualizar los valores del producto
                productoSeleccionado.Nombre = txtNombre.Text;
                productoSeleccionado.Codigo = txtCodigo.Text;
                productoSeleccionado.CategoriaId = (int)cmbCategoria.SelectedValue;
                productoSeleccionado.ProveedorId = (int)cmbProveedor.SelectedValue;
                productoSeleccionado.Precio = decimal.Parse(txtPrecio.Text);
                productoSeleccionado.Existencia = int.Parse(txtExistencia.Text);

                productoController.EditarProducto(productoSeleccionado);
                MessageBox.Show("Producto editado exitosamente.");
                CargarProductos(); // Refrescar la lista de productos
            }
            else
            {
                MessageBox.Show("Por favor, selecciona un producto para editar.");
            }
        }

        // Evento cuando se hace clic en el botón de eliminar producto
        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgvProductos.SelectedRows.Count > 0)
            {
                Producto productoSeleccionado = (Producto)dgvProductos.SelectedRows[0].DataBoundItem;
                productoController.EliminarProducto(productoSeleccionado.Id);
                MessageBox.Show("Producto eliminado exitosamente.");
                CargarProductos(); // Refrescar la lista de productos
            }
            else
            {
                MessageBox.Show("Por favor, selecciona un producto para eliminar.");
            }
        }

        // Eventos de cambios en los campos de texto (si necesitas hacer validaciones en tiempo real)
        private void txtPrecio_TextChanged(object sender, EventArgs e)
        {
            // Validar el formato del precio si es necesario
        }

        private void txtExistencia_TextChanged(object sender, EventArgs e)
        {
            // Validar que la existencia sea un número si es necesario
        }

        private void txtCodigo_TextChanged(object sender, EventArgs e)
        {
            // Validar el código del producto si es necesario
        }

        private void txtNombre_TextChanged(object sender, EventArgs e)
        {
            // Validar el nombre del producto si es necesario
        }

        // Evento para el clic de los labels (puedes agregar alguna acción o dejarlos vacíos)
        private void label1_Click(object sender, EventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void label4_Click(object sender, EventArgs e) { }
        private void label5_Click(object sender, EventArgs e) { }
        private void label6_Click(object sender, EventArgs e) { }
    }
}
